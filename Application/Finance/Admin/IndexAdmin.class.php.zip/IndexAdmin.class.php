<?php
// +----------------------------------------------------------------------
// | OpenCMF [ Simple Efficient Excellent ]
// +----------------------------------------------------------------------
// | Copyright (c) 2014 http://www.opencmf.cn All rights reserved.
// +----------------------------------------------------------------------
// | Author: jry <598821125@qq.com>
// +----------------------------------------------------------------------
namespace Finance\Admin;
use Admin\Controller\AdminController;
use Common\Util\Think\Page;
/**
 * 
 * @author bigfoot
 */
class IndexAdmin extends AdminController {
    
    /**
     * 默认方法
     * @author bigfoot
     */
    public function index() {
        
    }
    
    /*
     * 汇款信息列表 remittanceAdviceList
     * @author bigfoot
     */
     public function remit(){
        // 搜索
        $keyword   = I('keyword', '', 'string');
        $condition = array('like','%'.$keyword.'%');
        $map['bank_name|account_name'] = array(
            $condition,
            $condition,
            '_multi'=>true
        );
        $status = I('get.status');
        if(isset($status) && $status != ''){
           $map['status'] = $status; 
        }else{
            $map['status'] = array('egt', '0'); // 禁用和正常状态
        }
        
        // 获取所有汇款信息
        
        $p = !empty($_GET["p"]) ? $_GET['p'] : 1;
        $remit_object = M('finance_remittance');
        $data_list = $remit_object
                   ->page($p , C('ADMIN_PAGE_ROWS'))
                   ->where($map)
                   ->order('id desc')
                   ->select();
        $page = new Page(
            $remit_object
            ->where($map)
            ->count(),
            C('ADMIN_PAGE_ROWS')
        );
         $attr['name']  = 'forbid';
         $attr['title'] = '处理';
         $attr['class'] = 'label label-success ajax-get confirm';
         $attr['data-toggle'] = 'modal';
         // $attr['href']  = U('Caiwu/coinedit', array('uid' => '__data_id__'));
         $attr['href']  = U(MODULE_NAME.'/'.CONTROLLER_NAME.'/setStatus',
                            array(
                                'status' => 'resume',
                                'ids' => '__data_id__',
                                'model' => 'finance_remittance')
                            );
        //自定义按钮顶部批量处理
         $attr2['title'] = '处理';
         $attr2['class'] = 'btn btn-primary ajax-post confirm';
         $attr2['href']  = U(MODULE_NAME.'/'.CONTROLLER_NAME.'/setStatus',
                            array(
                                'status' => 'resume',
                                'model' => 'finance_remittance')
                            );
         // 使用Builder快速建立列表页面。
        $builder = new \Common\Builder\ListBuilder();
        $builder->setMetaTitle('汇款通知列表') // 设置页面标题
                ->addTopButton('delete', array('model' => 'finance_remittance'))  // 添加删除按钮
                ->addTopButton('self', $attr2)
                ->setSelectSearch('status','处理状态',
                                    array( '0'=>'未处理',
                                    '1'=>'已处理' ))   
                ->setSearch('请输入开户行／姓名', U('remit'))
                ->addTableColumn('id', 'ID')
                ->addTableColumn('bank_name', '开户行')
                ->addTableColumn('card_no', '银行卡号')
                ->addTableColumn('account_name', '开户名')
                ->addTableColumn('uid', '汇款人用户名','callback','get_user_name')
                ->addTableColumn('value', '汇款金额')
                ->addTableColumn('remit_pic', '汇款通知单','picture')
                ->addTableColumn('detail', '备注')
                ->addTableColumn('create_time', '汇款时间', 'time')
                ->addTableColumn('status', '状态', 'status')
                ->addTableColumn('right_button', '操作', 'btn')
                ->setTableDataList($data_list)    // 数据列表
                ->setTableDataPage($page->show()) // 数据列表分页
                ->addRightButton('delete',array('model' => 'finance_remittance'))
                ->addRightButton('self', $attr)   
                ->display();
     }
     
     /*
     * 提现申请列表 remittanceAdviceList
     * @author bigfoot
     */
     public function getMoney(){
        // 搜索
        $keyword   = I('keyword', '', 'string');
        $condition = array('like','%'.$keyword.'%');
        $map['uid|account_name'] = array(
            get_user_id($condition),
            $condition,
            '_multi'=>true
        );
        $status = I('get.status');
        if(isset($status) && $status != ''){
           $map['status'] = $status; 
        }else{
            $map['status'] = array('egt', '0'); // 禁用和正常状态
        }
        
        // 获取所有提现信息
        $p = !empty($_GET["p"]) ? $_GET['p'] : 1;
        $money_object = M('finance_getmoney');
        $data_list = $money_object
                   ->page($p , C('ADMIN_PAGE_ROWS'))
                   ->where($map)
                   ->order('id desc')
                   ->select();
        $page = new Page(
            $money_object
            ->where($map)
            ->count(),
            C('ADMIN_PAGE_ROWS')
        );
         $attr['name']  = 'forbid';
         $attr['title'] = '处理';
         $attr['class'] = 'label label-success ajax-get confirm';
         // $attr['href']  = U('setstatus/status/forbid', array('id' => '__data_id__'));
         $attr['href']  = U(MODULE_NAME.'/'.CONTROLLER_NAME.'/setStatus',
                            array(
                                'status' => 'resume',
                                'ids' => '__data_id__',
                                'model' => 'finance_getmoney')
                            );
         //自定义按钮顶部批量处理
         $attr2['title'] = '处理';
         $attr2['class'] = 'btn btn-primary ajax-post confirm';
         $attr2['href']  = U(MODULE_NAME.'/'.CONTROLLER_NAME.'/setStatus',
                            array(
                                'status' => 'resume',
                                'model' => 'finance_getmoney')
                            );
         // 使用Builder快速建立列表页面。
        $builder = new \Common\Builder\ListBuilder();
        $builder->setMetaTitle('提现申请表') // 设置页面标题
                ->addTopButton('delete', array('model' => 'finance_getmoney'))  // 添加删除按钮
                ->addTopButton('self', $attr2)  // 添加处理按钮
                ->setSelectSearch('status','处理状态',
                                    array( '0'=>'未处理',
                                    '1'=>'已处理' )) 
                ->setSearch('请输入用户名／开户名', U('getmoney'))
                ->addTableColumn('id', 'ID')
                ->addTableColumn('uid', '用户名','callback','get_user_name')
                ->addTableColumn('bank_name', '开户行')
                ->addTableColumn('card_no', '银行卡号')
                ->addTableColumn('account_name', '开户名')
                ->addTableColumn('value', '金额')
                ->addTableColumn('detail', '备注')
                ->addTableColumn('create_time', '申请时间', 'time')
                ->addTableColumn('remit_time', '处理时间', 'time')
                ->addTableColumn('status', '状态', 'status')
                ->addTableColumn('right_button', '操作', 'btn')
                ->setTableDataList($data_list)    // 数据列表
                ->setTableDataPage($page->show()) // 数据列表分页
                ->addRightButton('delete',array('model' => 'finance_getmoney'))
                ->addRightButton('self', $attr)   
                ->display();
     }
     
      /**
     * 设置一条或者多条数据的状态
     * @author jry <598821125@qq.com>
     */
    public function setStatus($model = CONTROLLER_NAME){
        $ids = I('request.ids');
        $status = I('request.status');
        if (empty($ids)) {
            $this->error('请选择要操作的数据');
        }
        $map['id'] = array('in',$ids);
        if ($status == 'resume'){
            $exist = D($model)->where($map)->getField('status');
            // dump($exist);
            if ($exist != 1) {//检查是否已经处理
                $data['status'] = 1;
                $data['remit_time'] = time();
                $delivery = D($model)->where($map)->setField($data);
            } else {
                $this->error('信息已经处理');
            }
            if ($delivery){
                $this->success('处理成功');
            }else{
                $this->error('处理失败');
            }
        }else{
            parent::setStatus($model);
        }
        
    }

}
